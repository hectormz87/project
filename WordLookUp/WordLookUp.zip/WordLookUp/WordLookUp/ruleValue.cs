﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordLookUp
{
    public class ruleValue
    {
        public bool isTermination { get; set; }
        public int order { get; set; }
        public int rule { get; set; }
    }
}
